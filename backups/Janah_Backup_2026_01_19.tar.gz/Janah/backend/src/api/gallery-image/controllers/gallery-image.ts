/**
 * gallery-image controller
 */

import { factories } from '@strapi/strapi'

export default factories.createCoreController('api::gallery-image.gallery-image');

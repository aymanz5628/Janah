'use client';

import { useEffect, useRef } from 'react';
import Image from 'next/image';
import styles from './ArticleBody.module.css';

interface ArticleBodyProps {
  content: string;
  image?: string;
  rawHtml?: string;
  useRawHtml?: boolean;
}

// Render actual article content from Strapi
// Supports both regular content and raw HTML with full CSS/animations
export default function ArticleBody({ content, image, rawHtml, useRawHtml }: ArticleBodyProps) {
  const rawHtmlRef = useRef<HTMLDivElement>(null);

  // Determine which content to render
  const shouldUseRawHtml = useRawHtml && rawHtml && rawHtml.trim().length > 0;
  const finalContent = shouldUseRawHtml ? rawHtml : content;
  
  // Check if content looks like HTML (contains tags)
  const isHtml = finalContent && (finalContent.includes('<') || finalContent.includes('&lt;'));

  // Handle raw HTML with style tags - inject them properly
  useEffect(() => {
    if (shouldUseRawHtml && rawHtmlRef.current && rawHtml) {
      // Parse the HTML and extract style tags
      const parser = new DOMParser();
      const doc = parser.parseFromString(rawHtml, 'text/html');
      
      // Get all style elements
      const styleElements = doc.querySelectorAll('style');
      
      // Create a unique ID for these styles
      const styleId = 'raw-html-styles-' + Date.now();
      
      // Remove any old injected styles
      document.querySelectorAll('[data-raw-html-style]').forEach(el => el.remove());
      
      // Inject styles into head
      styleElements.forEach((styleEl) => {
        const newStyle = document.createElement('style');
        newStyle.textContent = styleEl.textContent;
        newStyle.setAttribute('data-raw-html-style', styleId);
        document.head.appendChild(newStyle);
      });
      
      // Get body content (without style tags)
      const bodyContent = doc.body.innerHTML;
      rawHtmlRef.current.innerHTML = bodyContent;
      
      // Cleanup on unmount
      return () => {
        document.querySelectorAll(`[data-raw-html-style="${styleId}"]`).forEach(el => el.remove());
      };
    }
  }, [shouldUseRawHtml, rawHtml]);
  
  return (
    <div className={styles.body}>
      {/* Only show image if NOT using rawHtml (rawHtml handles its own layout) */}
      {!shouldUseRawHtml && image && (
        <div className={styles.imageWrapper}>
          <Image src={image} alt="Article Image" fill className={styles.image} />
        </div>
      )}
      
      {/* Raw HTML mode - full control */}
      {shouldUseRawHtml ? (
        <div 
          ref={rawHtmlRef}
          className={styles.rawHtmlContent}
        />
      ) : (
        /* Regular content mode */
        finalContent && (
          isHtml ? (
            <div 
              className={styles.content}
              dangerouslySetInnerHTML={{ __html: finalContent }} 
            />
          ) : (
            <div className={styles.content}>
              {finalContent.split('\n').map((paragraph, index) => (
                paragraph.trim() && <p key={index}>{paragraph}</p>
              ))}
            </div>
          )
        )
      )}
      
      {!finalContent && !shouldUseRawHtml && (
        <p className={styles.noContent}>لا يوجد محتوى لهذه المقالة.</p>
      )}
    </div>
  );
}
